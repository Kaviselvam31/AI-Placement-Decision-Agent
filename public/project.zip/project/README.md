# Placement Decision AI Agent

An AI-powered placement mentor that analyzes a student's academic profile, technical skills, projects, resume, and career goal, then delivers a personalized placement readiness report using Google Gemini.

Built for the AI Agent Development Challenge.

## Features

- Modern SaaS-style landing page with glassmorphism, gradients, and Framer Motion animations
- Multi-step assessment form with validation and progress bar
- Animated AI processing screen with staged status messages
- Gemini-powered analysis via a Supabase Edge Function (with an optional Express backend included)
- Professional dashboard with circular readiness score, radar chart, roadmap timeline, skill gap analysis, recommended companies, projects, certifications, interview questions, and a final recommendation
- One-click PDF report download (jsPDF)
- Dark mode toggle with system preference detection
- Fully responsive across mobile, tablet, and desktop

## Tech Stack

- **Frontend:** React (Vite), TypeScript, Tailwind CSS, React Router, Framer Motion, Recharts, Lucide React, jsPDF
- **AI:** Google Gemini (`gemini-2.0-flash` by default; configurable)
- **Backend (default):** Supabase Edge Function (Deno)
- **Backend (optional):** Node.js + Express (in `backend/`)

## Project Structure

```
project/
  src/
    components/
      ui/            - Reusable UI primitives (Button, Card, Navbar, Footer, ScoreCircle, ProgressBar, SectionHeading)
      landing/       - Landing page sections (Hero, About, Features, HowItWorks, Benefits, FAQ, CTA)
      assessment/    - Assessment step components and step indicator
      dashboard/     - Dashboard report sections and radar chart
    pages/           - LandingPage, AssessmentPage, ProcessingPage, DashboardPage
    hooks/           - useDarkMode, useLocalStorage
    services/        - aiService (calls the Supabase Edge Function)
    utils/           - cn (classnames), pdfGenerator (jsPDF)
    data/            - assessmentOptions (skills, roles, departments)
    types/           - shared TypeScript types
  backend/           - Optional Express backend (config, controllers, middleware, routes, services)
  supabase/functions/analyze-placement/ - Default backend (Deno Edge Function)
```

## Getting Started

### Prerequisites

- Node.js 18+
- A Google Gemini API key from https://aistudio.google.com/app/apikey

### 1. Install frontend dependencies

```bash
npm install
```

### 2. Configure your Gemini API key

The frontend calls a Supabase Edge Function by default. The Edge Function is already deployed to the provisioned Supabase project; you only need to set the `GEMINI_API_KEY` secret once.

Run this in a terminal (replace `YOUR_GEMINI_API_KEY`):

```bash
npx supabase secrets set GEMINI_API_KEY=YOUR_GEMINI_API_KEY --project-ref <your-project-ref>
```

If you do not have the Supabase CLI, you can also set the secret from the Supabase dashboard: Project Settings -> Edge Functions -> Secrets.

> The frontend already has `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` populated in `.env`. Do not change them.

### 3. Run the dev server

```bash
npm run dev
```

The app opens at the URL printed in the terminal.

### 4. Build for production

```bash
npm run build
```

The production bundle is written to `dist/`.

## Using the optional Express backend

If you prefer to run a standalone Node backend instead of the Supabase Edge Function:

1. `cd backend && npm install`
2. `cp .env.example .env` and set `GEMINI_API_KEY`
3. `npm start`
4. In `src/services/aiService.ts`, replace the `supabase.functions.invoke('analyze-placement', ...)` call with a `fetch` to `http://localhost:5000/api/analyze`.

See `backend/README.md` for details.

## Application Flow

1. **Landing Page** - hero, features, how it works, benefits, FAQ, CTA
2. **Assessment** - 5-step form (personal, skills, experience, levels, target role + resume)
3. **AI Processing** - animated staged loading screen while Gemini analyzes the profile
4. **Dashboard** - placement score, summary, strengths/weaknesses, skill gaps, best role, recommended companies, 30-day roadmap, projects, certifications, tips, interview questions, final recommendation
5. **Download PDF** - one-click export of the full report

## Error Handling

- If the Gemini API key is missing, the dashboard shows a clear error message and the user can retry or return to the assessment.
- API errors are surfaced with a friendly message and a retry button on the processing screen.
- The assessment form validates each step before allowing the user to proceed.

## License

Built for the AI Agent Development Challenge. Use it, fork it, demo it.
